import java.util.Random;

public class ejemploBuscarPlacas {
    public static int dimension = 500;
    public static Patente[] placasRegistradas = new Patente[dimension];
    public static Patente[] placasNoRegistradas = new Patente[dimension];
    public static Random random = new Random();
    /**
     * log: Wrapper de la funcion System.out.print
     * @param str para imprimir
     */
    public static void log(String str) {
        System.out.print("\n" + str);
    }
    /**
     * crearPlacaRandomizada: crea una Placa nueva con letras y números aleatorios,
     * los números el límite superior es 10, solo se crean números aleatorios del 1 al 10
     * lo anterior para obligar a muchas placas diferentes a compartir el mismo número
     * @param límiteInferior: se suma al número aleatorio para obtener el límite inferior
     */
    public static Patente crearPlacaRandomizada(int límiteInferior) {
        final String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWX"; final int N = alphabet.length();
        String letras = "" + alphabet.charAt(random.nextInt(N)) + alphabet.charAt(random.nextInt(N));;
        int numeros= random.nextInt(10) + límiteInferior;
        return new Patente(numeros, letras);

    }

    /**
     * registrarPlacasCondominio: Éste metodo "inicializa" la tabla de patentes, inserta las placas de los
     * condóminos, en éste caso en particular crea placas randomizadas y las incluye, también crea placas
     * randomizadas y no las incluye para probar las funcionalidades de la clase.
     * @param tabla
     */
    public static void registrarPlacasCondominio(TablaDePatentes tabla) {

        int i = 0;
        while (i < dimension) {
            placasRegistradas[i] = crearPlacaRandomizada(1000);
            placasNoRegistradas[i] = crearPlacaRandomizada(2000);
            if (i % 3 == 0) {
                placasNoRegistradas[i] = new Patente(placasRegistradas[i].obtNumero(),"YZ");
            }
            i++;
        }
        placasRegistradas[(dimension - 1)] = new Patente(placasRegistradas[(dimension - 2)].obtNumero(), placasRegistradas[(dimension - 3)].obtLetras());
        for (int j = 0; j < dimension; j++) {
            tabla.guardarPlaca(placasRegistradas[j]);
        }

    }

    /**
     * buscarPlaca: recibe una tabla de patentes, genera un número aleatorio con límite superior de la dimensión
     * de un array de placas registradas, si ése número aleatorio es par toma una placa del array de placas no registradas
     * si no es par lo toma del array de placas registradas, posteriormente pasa la placa al método buscar de la clase
     * TablaDePatentes y regresa un boolean
     * @param tabla
     * @return boolean
     */
    public static boolean buscarPlaca(TablaDePatentes tabla) {
        int indicePlaca = random.nextInt(placasRegistradas.length);
        Patente[] pr = placasRegistradas;
        if (indicePlaca != 0 && (indicePlaca % 2) == 0) {
            pr = placasNoRegistradas;
        }

        log("\n--- Buscando placa " + pr[indicePlaca].obtLetras() + pr[indicePlaca].obtNumero());
        if (tabla.buscar(pr[indicePlaca])) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * buscarPlacas: invoca el método buscarPlaca el número indicado de veces por nPlacas sobre la tabla que recibe como
     * argumento
     * @param tabla
     * @param nPlacas
     */
    public static void buscarPlacas(TablaDePatentes tabla, int nPlacas) {
        int i = 0;
        while (i < nPlacas) {
            buscarPlaca(tabla);
            i++;
        }

    }
    public static void main(String[] args)
    {
        TablaDePatentes tabla = new TablaDePatentes();
        registrarPlacasCondominio(tabla);
        buscarPlacas(tabla,20);

    }

}
